(function() {
  // Zone: content-top (above directory listing, below banner)

  function injectStylesheet() {
    // Prevent duplicate injections
    if (document.getElementById('evodir-kpi-styles')) return;

    var link = document.createElement('link');
    link.id = 'evodir-kpi-styles';
    link.rel = 'stylesheet';
    link.href = '/.includes/modules/kpi/module.css'; // Update path if needed

    // Find the first theme stylesheet to insert BEFORE it
    var themeLink = document.querySelector('link[href*="theme"], link[id*="theme"]');
    if (themeLink && themeLink.parentNode) {
      themeLink.parentNode.insertBefore(link, themeLink);
    } else {
      document.head.appendChild(link);
    }
  }

  function waitForZone(cb, attempts) {
    attempts = attempts || 0;
    var zone = document.getElementById('evodir-zone-content-top');
    if (zone) { cb(zone); return; }
    if (attempts < 20) setTimeout(function() { waitForZone(cb, attempts + 1); }, 150);
  }

  function kpiCard(icon, title, value, colorVar) {
    // Fallback logic uses custom property or accents safely
    var headerBg = 'var(' + colorVar + ', var(--accent, #4a9eff))';
    
    return '<div class="evodir-kpi-card">' +
      // Header Ribbon
      '<div class="evodir-kpi-header" style="background: ' + headerBg + ';">' +
        '<i class="bi ' + icon + '"></i>' +
        '<span>' + title + '</span>' +
      '</div>' +
      // Card Body
      '<div class="evodir-kpi-body">' +
        '<i class="bi ' + icon + ' evodir-kpi-body-icon" style="color: ' + headerBg + ';"></i>' +
        '<span class="evodir-kpi-value">' + value + '</span>' +
      '</div>' +
    '</div>';
  }

  // Inject the structural stylesheet immediately
  injectStylesheet();

  waitForZone(function(zone) {
    var banner = document.getElementById('evodir-banner');

    var kpiBar = document.createElement('div');
    kpiBar.id = 'evodir-kpi-bar';

    if (banner && banner.parentNode === zone) {
      zone.insertBefore(kpiBar, banner.nextSibling);
    } else {
      zone.insertBefore(kpiBar, zone.firstChild);
    }

    fetch('/.includes/api.php?action=kpi&path=' + encodeURIComponent(window.location.pathname))
      .then(function(r) { return r.json(); })
      .then(function(d) {
        var NA = '-';
        var html = '';

        html += kpiCard('bi-folder2',     'Folders',  d.folders     !== null ? d.folders.toLocaleString()     : NA, '--kpi-color-folders');
        html += kpiCard('bi-file-earmark','Files',    d.files       !== null ? d.files.toLocaleString()       : NA, '--kpi-color-files');

        if (d.plex_movies !== null)
          html += kpiCard('bi-film',      'Movies',   d.plex_movies.toLocaleString(), '--kpi-color-movies');
        if (d.plex_shows !== null)
          html += kpiCard('bi-tv',        'TV Shows', d.plex_shows.toLocaleString(),  '--kpi-color-shows');
        if (d.plex_songs !== null)
          html += kpiCard('bi-music-note','Songs',    d.plex_songs.toLocaleString(),  '--kpi-color-songs');

        kpiBar.innerHTML = html;
      })
      .catch(function() {
        kpiBar.innerHTML = '';
      });
  });
})();