<?php
/**
 * EvoDir KPI Module
 * Shows folder/file counts for current directory and Plex library stats.
 * Homelab only — requires access to Plex SQLite database.
 */

global $conf;
$kpi_conf = $conf['kpi'] ?? [];

$webroot = rtrim($_SERVER['DOCUMENT_ROOT'], '/');
$reqPath = isset($_GET['path']) ? $_GET['path'] : '/';
$reqPath = '/' . trim(str_replace('..', '', $reqPath), '/');
$absPath = rtrim($webroot . $reqPath, '/');

// Count files and folders in current directory (non-recursive)
$file_count   = 0;
$folder_count = 0;
$skip = ['.htaccess', '.includes', '.legal', '.git'];

try {
    $entries = @scandir($absPath);
    if ($entries) {
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') continue;
            if (in_array($entry, $skip)) continue;
            $full = $absPath . '/' . $entry;
            if (is_dir($full)) $folder_count++;
            else $file_count++;
        }
    }
} catch (Throwable $e) {}

// Plex stats from SQLite
$plex_movies  = null;
$plex_shows   = null;
$plex_songs   = null;
$plex_db      = $kpi_conf['plex_db'] ?? '/DATA/AppData/big-bear-plex/config/Library/Application Support/Plex Media Server/Plug-in Support/Databases/com.plexapp.plugins.library.db';
$movie_section = (int)($kpi_conf['plex_movie_section'] ?? 7);
$show_section  = (int)($kpi_conf['plex_show_section']  ?? 5);

try {
    if (file_exists($plex_db) && class_exists('SQLite3')) {
        $db = new SQLite3($plex_db, SQLITE3_OPEN_READONLY);
        $db->busyTimeout(2000);

        // Movies
        $stmt = $db->prepare('SELECT count(*) FROM metadata_items WHERE metadata_type = 1 AND library_section_id = :sid');
        $stmt->bindValue(':sid', $movie_section, SQLITE3_INTEGER);
        $result = $stmt->execute();
        if ($result) $plex_movies = (int)$result->fetchArray()[0];

        // TV Shows
        $stmt = $db->prepare('SELECT count(*) FROM metadata_items WHERE metadata_type = 2 AND library_section_id = :sid');
        $stmt->bindValue(':sid', $show_section, SQLITE3_INTEGER);
        $result = $stmt->execute();
        if ($result) $plex_shows = (int)$result->fetchArray()[0];

        // Songs (type 10, all sections)
        $result = $db->query('SELECT count(*) FROM metadata_items WHERE metadata_type = 10');
        if ($result) $plex_songs = (int)$result->fetchArray()[0];

        $db->close();
    }
} catch (Throwable $e) {}

return [
    'kpi' => [
        'folders'      => $folder_count,
        'files'        => $file_count,
        'plex_movies'  => $plex_movies,
        'plex_shows'   => $plex_shows,
        'plex_songs'   => $plex_songs,
        'path'         => $reqPath,
    ]
];
